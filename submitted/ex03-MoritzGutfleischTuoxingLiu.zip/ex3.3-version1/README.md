# Instructions

Use `make` to build the executable, run `sbatch pow2batch.sh` to execute the kernel for different data sizes.
