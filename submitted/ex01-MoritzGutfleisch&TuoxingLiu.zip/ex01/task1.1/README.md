# README

## Configure

If you want to configure the behavior of the program, change line 77 and line 78

```
#define IS_COPYKERNEL 0 // 0: original, 1: using copyKernel
#define COPY_SIZE 1     // possible value: 1, 4, 8, 16
```

Then compile again.
