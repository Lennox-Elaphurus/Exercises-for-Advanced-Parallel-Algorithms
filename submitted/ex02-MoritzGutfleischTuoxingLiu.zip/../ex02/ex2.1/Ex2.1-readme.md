# Ex2.1

- To set the boundary to an arbitrary float value: 

add `boundary= some float`when executing the file FDTD3d. For example: `./FDTD3d boundary=0.5`

- The following values are defined in `FDTD3d.h`:
    - The default value of boundary is `0.0f`. 
    - The minimum value of boundary is `0.0f`. 
    - The maximum value of boundary is `1.0f`. 

